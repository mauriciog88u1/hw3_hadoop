package csx55.hw3.utils;


public class metadata {
    private metadata() {}

    public static final int ARTIST_FAMILIARITY_INDEX = 0;
    public static final int ARTIST_HOTTTNESSS_INDEX = 1;
    public static final int ARTIST_ID_INDEX = 2;
    public static final int ARTIST_LATITUDE_INDEX = 3;
    public static final int ARTIST_LONGITUDE_INDEX = 4;
    public static final int ARTIST_LOCATION_INDEX = 5;
    public static final int ARTIST_NAME_INDEX = 6;
    public static final int SONG_ID_INDEX = 7;
    public static final int TITLE_INDEX = 8;
    public static final int SIMILAR_ARTISTS_INDEX = 9;
    public static final int ARTIST_TERMS_INDEX = 10;
    public static final int ARTIST_TERMS_FREQ_INDEX = 11;
    public static final int ARTIST_TERMS_WEIGHT_INDEX = 12;
    public static final int YEAR_INDEX = 13;




}

