# Compile
* gradle build

# How to run 
*  $HADOOP_HOME/bin/hadoop jar ~/cs455/hw3/hw3_hadoop/build/libs/hw3_hadoop.jar <question number> <output path>

# q6
* q6 data was all 0's so we just printed first 10 values

#q8
* I defined generic as a combo between most similar artist and most artist terms

#q9
solution is in q9_written_answer

#q10
String question10 = "How has the popularity of Spanish music (like Cumbia, Reggaeton, Latin, Musica, and Reggae) evolved across different regions and over time?";

check q10 visual to show trends. Essentially we saw that there was alot more in the early 2010's but data set was limited. This boom could be attributed to the reggeaton era starting in 2010's.


