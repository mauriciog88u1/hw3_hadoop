
# Q9
To asnwer q9 we averaged data from all songs with a hotness of 1 and used that to create the song bellow.

SONG NAME: La Cumbia de el Cookie by Lul Jaime



- **Artist:** Lul Jaime
- **Hotness:** 1.01 (fictionally set as data shows 1.01, assuming improvement for higher hotness)
- **Title:** La Cumbia de el Cookie
- **Year:** 2010
- **Duration:** 207 seconds (average of 145.06 and 269.64)
- **Tempo:** 127 BPM (averaged between 150.57 and 104.04)
- **Danceability:** 0.8 (fictionally set as data shows 0.00, assuming improvement for higher hotness)
- **Energy:** 0.7 (fictionally set as data shows 0.00, assuming improvement for higher hotness)
- **Loudness:** -8 dB (between -10.54 and -5.39)
- **Time Signature:** 4 (common time, fitting for the genre)
- **Mode:** Major (1, which aligns with typical major tonality in upbeat songs)
- **Key:** 10.5 rounded to 11 (between F# major and a nearby key, sticking with F# major as it is exactly 11)
- **Fade In End Time:** 3.75 seconds (average between 2.22 and 5.28)
- **Fade Out Start Time:** 199 seconds (average between 140.13 and 258.46)

This song will be a reggaeton/cumbia song by fictional artist Lul Jaime, who would be known for his fast tempo
and high-energy songs. The song will be danceable with a major tonality and a key of F# major. It will be 207 seconds long
and will have a fade-in end time of 3.75 seconds and a fade-out start time of 199 seconds.
